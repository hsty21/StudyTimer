# Study Timer

An offline tracker for studying and working. Start a timer, pause it when you step away,
finish it and write down what you actually got done. Everything lands in a calendar.

No account, no analytics, no internet permission in the manifest.

---

## Building it

Same route as Reading Timer. Upload this zip to a **new** GitHub repo, then create the file
`.github/workflows/build.yml` through **Add file → Create new file** and paste the contents
of `.github/workflows/build.yml` from inside this zip. The Actions tab builds it and hands
you an APK named `study-timer-apk`.

Or open the folder in Android Studio and press Run.

Minimum Android version: 8.0 (API 26).

---

## How it works

### Timer tab

**Start** begins a session. **Pause** freezes the clock — the paused time is not counted.
**Resume** picks it back up. **Finish** stops everything and opens the task dialog.

All three also live on the notification, so you can pause without unlocking the tablet.
The clock banks completed stretches as milliseconds and remembers the instant the current
stretch began, so locking the screen, switching apps, or the process being killed can never
lose or invent time.

**Cancel without saving** throws the whole session away.

### The task dialog

Add as many tasks as you like. Each one takes a name, and optionally hours and minutes of
its own. Names you have typed before appear as chips under the field once you start typing —
tap one to fill it in.

Your rule about mismatched time is built in:

- Task times add up to **more** than the clock recorded → the session stretches to match, and
  the dialog tells you before you save.
- Task times add up to **less** → the remainder is recorded as **unassigned time**, shown on
  the session in the calendar.
- No task times at all → the whole session is unassigned, which is fine.

### Add a session by hand

The button under the timer. Pick any date, a start time, a duration, and the same task list.
Useful for the days you forget to press Start.

### Calendar tab

**Month** shows a grid with worked days tinted and their totals; tap a day to see it.
**All days** lists every day with work on it, newest first.

Within a day there are two toggles:

- **Grid / List** — tasks as two-column cards, or as full-width rows
- **By session / All tasks** — split under each session, or pooled for the whole day

Each task shows its name, and its time when you gave it one. Every session can be edited or
deleted with the pencil and bin icons.

### Data tab

All-time totals, your most-logged task names, and the backup buttons.

**Export JSON** writes a file wherever you pick — Drive, Downloads, anywhere. **Import JSON**
reads one back, which is how you restore after a reinstall or move to another Android device.
Importing replaces everything currently in the app.

---

## Look

Colours are taken from the purple-to-magenta gradient you sent: near-black indigo at the top
of the screen easing into violet and magenta, with pastel pink and lilac as accents. Text
stays near-white so long sessions don't tire your eyes.

Light and dark both follow the tablet's system setting.

Your stickers are cut out to transparent PNGs and tucked faintly into screen corners — the
witch hat and potion bottle on the Timer tab, the ghost and cauldron on the Calendar, the
witch and her cat on the Data tab.

---

## Where the data lives

One file, `study_data.json`, in the app's private storage. Uninstalling deletes it, which is
what the export button is for.

---

## If the notification disappears

Samsung One UI is aggressive with background apps:

**Settings → Apps → Study Timer → Battery → Unrestricted**

The recorded time stays correct regardless, since it comes from timestamps rather than from
the service staying alive.

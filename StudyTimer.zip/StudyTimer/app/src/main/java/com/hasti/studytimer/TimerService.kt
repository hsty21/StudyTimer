package com.hasti.studytimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.hasti.studytimer.data.TimerSnapshot
import com.hasti.studytimer.data.TimerState
import java.util.Locale

/**
 * Holds the ongoing notification while a session runs. When the clock is running the
 * notification counts up by itself using the system chronometer; when paused it shows a
 * frozen total. Either way this service does no periodic work.
 */
class TimerService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.hasti.studytimer.UPDATE"
        const val ACTION_PAUSE = "com.hasti.studytimer.PAUSE"
        const val ACTION_RESUME = "com.hasti.studytimer.RESUME"
        const val ACTION_FINISH = "com.hasti.studytimer.FINISH"

        private const val CHANNEL_ID = "study_session"
        private const val NOTIF_ID = 2001

        /** Start the service, or refresh its notification after a state change. */
        fun update(context: Context) {
            val intent = Intent(context.applicationContext, TimerService::class.java)
                .setAction(ACTION_UPDATE)
            ContextCompat.startForegroundService(context.applicationContext, intent)
        }

        fun stop(context: Context) {
            context.applicationContext.stopService(
                Intent(context.applicationContext, TimerService::class.java)
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        TimerState.init(this)

        when (intent?.action) {
            ACTION_PAUSE -> TimerState.pause(this, notifyService = false)
            ACTION_RESUME -> TimerState.resume(this, notifyService = false)
            ACTION_FINISH -> {
                TimerState.finish(this, notifyService = false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val snapshot = TimerState.snapshot.value
        if (!snapshot.active) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification(snapshot))
        return START_STICKY
    }

    private fun buildNotification(snapshot: TimerSnapshot): Notification {
        createChannel()

        val now = System.currentTimeMillis()
        val elapsed = snapshot.elapsedAt(now)

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )

        fun serviceAction(action: String, requestCode: Int): PendingIntent =
            PendingIntent.getService(
                this, requestCode,
                Intent(this, TimerService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE
            )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (snapshot.running) "Session running" else "Session paused")
            .setSmallIcon(R.drawable.ic_timer)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setContentIntent(openApp)

        if (snapshot.running) {
            // Anchor the chronometer so it displays the banked time plus this segment.
            builder.setWhen(now - elapsed)
                .setUsesChronometer(true)
                .setShowWhen(true)
                .setContentText("Tap to open, or pause below")
                .addAction(R.drawable.ic_timer, "Pause", serviceAction(ACTION_PAUSE, 1))
        } else {
            builder.setShowWhen(false)
                .setUsesChronometer(false)
                .setContentText("Paused at ${clock(elapsed)}")
                .addAction(R.drawable.ic_timer, "Resume", serviceAction(ACTION_RESUME, 2))
        }

        builder.addAction(R.drawable.ic_timer, "Finish", serviceAction(ACTION_FINISH, 3))
        return builder.build()
    }

    private fun clock(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        return String.format(
            Locale.ENGLISH, "%02d:%02d:%02d",
            total / 3600, (total % 3600) / 60, total % 60
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Study session",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows the running timer while you study or work"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        manager.createNotificationChannel(channel)
    }
}

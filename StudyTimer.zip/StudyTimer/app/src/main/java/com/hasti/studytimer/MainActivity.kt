package com.hasti.studytimer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.hasti.studytimer.data.Repo
import com.hasti.studytimer.data.TimerState
import com.hasti.studytimer.ui.AppTheme
import com.hasti.studytimer.ui.StudyApp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(applicationContext)
        TimerState.init(applicationContext)
        setContent {
            AppTheme {
                StudyApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Pick up changes made from the notification's Pause / Resume / Finish buttons.
        TimerState.init(applicationContext)
    }
}

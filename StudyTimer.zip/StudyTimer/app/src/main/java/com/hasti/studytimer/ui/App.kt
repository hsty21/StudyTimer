package com.hasti.studytimer.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.hasti.studytimer.data.Repo
import com.hasti.studytimer.data.TimerState
import com.hasti.studytimer.data.WorkSession
import com.hasti.studytimer.data.resolveEndTime
import com.hasti.studytimer.data.taskNameHistory

private data class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("Timer", Icons.Default.PlayArrow),
    Tab("Calendar", Icons.Default.DateRange),
    Tab("Data", Icons.Default.Settings)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyApp() {
    val context = LocalContext.current
    val data by Repo.data.collectAsState()
    val snapshot by TimerState.snapshot.collectAsState()
    val pending by TimerState.pending.collectAsState()

    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    var editingSession by remember { mutableStateOf<WorkSession?>(null) }
    var deletingSession by remember { mutableStateOf<WorkSession?>(null) }
    var addingManual by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val history = remember(data.sessions) { data.taskNameHistory() }

    GradientBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val wide = maxWidth > 720.dp

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = { Text(tabs[tabIndex].label) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent
                        )
                    )
                },
                bottomBar = {
                    if (!wide) {
                        NavigationBar(containerColor = Color.Transparent) {
                            tabs.forEachIndexed { index, tab ->
                                NavigationBarItem(
                                    selected = tabIndex == index,
                                    onClick = { tabIndex = index },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(Modifier.fillMaxSize().padding(innerPadding)) {
                    if (wide) {
                        NavigationRail(containerColor = Color.Transparent) {
                            tabs.forEachIndexed { index, tab ->
                                NavigationRailItem(
                                    selected = tabIndex == index,
                                    onClick = { tabIndex = index },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }

                    Column(Modifier.fillMaxSize()) {
                        when (tabIndex) {
                            0 -> TimerScreen(
                                data = data,
                                snapshot = snapshot,
                                onStart = { TimerState.start(context) },
                                onPause = { TimerState.pause(context) },
                                onResume = { TimerState.resume(context) },
                                onFinish = { TimerState.finish(context) },
                                onCancel = { TimerState.cancel(context) },
                                onAddManual = { addingManual = true },
                                onEditSession = { editingSession = it },
                                onDeleteSession = { deletingSession = it },
                                modifier = Modifier.fillMaxSize()
                            )

                            1 -> CalendarScreen(
                                data = data,
                                wide = wide,
                                onEditSession = { editingSession = it },
                                onDeleteSession = { deletingSession = it },
                                modifier = Modifier.fillMaxSize()
                            )

                            else -> DataScreen(data = data, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
    }

    // A finished session waiting for its tasks.
    pending?.let { (start, totalMs) ->
        SessionEditorDialog(
            heading = "What did you get done?",
            allowDateTime = false,
            initialStart = start,
            initialMinutes = (totalMs / 60_000L).toInt(),
            initialTasks = emptyList(),
            history = history,
            dismissLabel = "Discard session",
            onSave = { startTime, timedMinutes, tasks ->
                Repo.addSession(
                    WorkSession(
                        startTime = startTime,
                        endTime = resolveEndTime(startTime, timedMinutes, tasks),
                        tasks = tasks
                    )
                )
                TimerState.clearPending(context)
            },
            onDismiss = { TimerState.clearPending(context) }
        )
    }

    if (addingManual) {
        SessionEditorDialog(
            heading = "Add a session",
            allowDateTime = true,
            initialStart = System.currentTimeMillis(),
            initialMinutes = 60,
            initialTasks = emptyList(),
            history = history,
            dismissLabel = "Cancel",
            onSave = { startTime, timedMinutes, tasks ->
                Repo.addSession(
                    WorkSession(
                        startTime = startTime,
                        endTime = resolveEndTime(startTime, timedMinutes, tasks),
                        tasks = tasks
                    )
                )
                addingManual = false
            },
            onDismiss = { addingManual = false }
        )
    }

    editingSession?.let { session ->
        SessionEditorDialog(
            heading = "Edit session",
            allowDateTime = true,
            initialStart = session.startTime,
            initialMinutes = session.minutes,
            initialTasks = session.tasks,
            history = history,
            dismissLabel = "Cancel",
            onSave = { startTime, timedMinutes, tasks ->
                Repo.updateSession(
                    session.copy(
                        startTime = startTime,
                        endTime = resolveEndTime(startTime, timedMinutes, tasks),
                        tasks = tasks
                    )
                )
                editingSession = null
            },
            onDismiss = { editingSession = null }
        )
    }

    deletingSession?.let { session ->
        ConfirmDialog(
            heading = "Delete this session?",
            message = "${formatMinutes(session.minutes)} and ${session.tasks.size} " +
                "task${if (session.tasks.size == 1) "" else "s"} will be removed.",
            onConfirm = {
                Repo.deleteSession(session.id)
                deletingSession = null
            },
            onDismiss = { deletingSession = null }
        )
    }
}

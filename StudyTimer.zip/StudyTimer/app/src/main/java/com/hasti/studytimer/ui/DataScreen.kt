package com.hasti.studytimer.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hasti.studytimer.R
import com.hasti.studytimer.data.AppData
import com.hasti.studytimer.data.Repo
import com.hasti.studytimer.data.taskNameHistory
import java.time.LocalDate

@Composable
fun DataScreen(data: AppData, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(Repo.exportJson().toByteArray()) }
            }.isSuccess
            Toast.makeText(
                context,
                if (ok) "Backup saved" else "Could not save backup",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            val ok = text != null && Repo.importJson(text)
            Toast.makeText(
                context,
                if (ok) "Backup restored" else "That file could not be read",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    val totalMinutes = data.sessions.sumOf { it.minutes }
    val assigned = data.sessions.sumOf { it.assignedMinutes }
    val unassigned = data.sessions.sumOf { it.unassignedMinutes }
    val taskCount = data.sessions.sumOf { it.tasks.size }
    val activeDays = data.sessions.map { it.date }.distinct().size
    val topTasks = data.taskNameHistory().take(5)

    Box(modifier.fillMaxSize()) {
        CornerSticker(
            resId = R.drawable.sticker_witch,
            alignment = Alignment.BottomEnd,
            size = 92.dp,
            alpha = 0.32f,
            rotation = -4f,
            modifier = Modifier.padding(end = 6.dp, bottom = 6.dp)
        )

        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                )
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("All time", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${formatMinutes(totalMinutes)}  \u00b7  $taskCount tasks  \u00b7  " +
                            "${data.sessions.size} sessions",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Text(
                        "Across $activeDays day${if (activeDays == 1) "" else "s"}" +
                            if (activeDays > 0) "  \u00b7  ${formatMinutes(totalMinutes / activeDays)} a day on average" else "",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (totalMinutes > 0) {
                        Text(
                            "${formatMinutes(assigned)} assigned to tasks, ${formatMinutes(unassigned)} unassigned",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (topTasks.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Most logged tasks", style = MaterialTheme.typography.titleMedium)
                        topTasks.forEach { name ->
                            Text("\u2022  $name", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Text("Backup", style = MaterialTheme.typography.titleMedium)
            Text(
                "Everything lives only on this tablet. Export a copy now and then, and import it " +
                    "if you reinstall or move to another Android device.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { exportLauncher.launch("study-backup-${LocalDate.now()}.json") },
                    modifier = Modifier.weight(1f)
                ) { Text("Export JSON") }
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text("Import JSON") }
            }
            Text(
                "Importing replaces everything currently in the app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(40.dp))
        }
    }
}

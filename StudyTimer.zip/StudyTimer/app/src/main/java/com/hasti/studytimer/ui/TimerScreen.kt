package com.hasti.studytimer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hasti.studytimer.R
import com.hasti.studytimer.data.AppData
import com.hasti.studytimer.data.TimerSnapshot
import com.hasti.studytimer.data.WorkSession
import com.hasti.studytimer.data.sessionsOn
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun TimerScreen(
    data: AppData,
    snapshot: TimerSnapshot,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onFinish: () -> Unit,
    onCancel: () -> Unit,
    onAddManual: () -> Unit,
    onEditSession: (WorkSession) -> Unit,
    onDeleteSession: (WorkSession) -> Unit,
    modifier: Modifier = Modifier
) {
    val today = LocalDate.now()
    val todaySessions = data.sessionsOn(today).sortedByDescending { it.startTime }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(snapshot.running) {
        while (snapshot.running) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }
    val elapsed = snapshot.elapsedAt(if (snapshot.running) now else System.currentTimeMillis())

    Box(modifier.fillMaxSize()) {
        CornerSticker(
            resId = R.drawable.sticker_hat,
            alignment = Alignment.TopEnd,
            size = 84.dp,
            alpha = 0.45f,
            rotation = 8f,
            modifier = Modifier.padding(top = 4.dp, end = 8.dp)
        )
        CornerSticker(
            resId = R.drawable.sticker_potion,
            alignment = Alignment.BottomStart,
            size = 66.dp,
            alpha = 0.28f,
            rotation = -10f,
            modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            snapshot.running -> MaterialTheme.colorScheme.primaryContainer
                            snapshot.paused -> MaterialTheme.colorScheme.secondaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                    )
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = formatClock(elapsed),
                            fontSize = 54.sp,
                            fontWeight = FontWeight.Light,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = when {
                                snapshot.running -> "Running since ${formatTimeOfDay(snapshot.sessionStart)}"
                                snapshot.paused -> "Paused \u00b7 started ${formatTimeOfDay(snapshot.sessionStart)}"
                                else -> "Ready when you are"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (!snapshot.active) {
                            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                                Text("Start")
                            }
                        } else {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (snapshot.running) {
                                    OutlinedButton(onClick = onPause, modifier = Modifier.weight(1f)) {
                                        Text("Pause")
                                    }
                                } else {
                                    OutlinedButton(onClick = onResume, modifier = Modifier.weight(1f)) {
                                        Text("Resume")
                                    }
                                }
                                Button(onClick = onFinish, modifier = Modifier.weight(1f)) {
                                    Text("Finish")
                                }
                            }
                            TextButton(onClick = onCancel) { Text("Cancel without saving") }
                        }
                    }
                }
            }

            item {
                val minutes = todaySessions.sumOf { it.minutes }
                val tasks = todaySessions.sumOf { it.tasks.size }
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Today", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${formatMinutes(minutes)}  \u00b7  $tasks task${if (tasks == 1) "" else "s"}" +
                                "  \u00b7  ${todaySessions.size} session${if (todaySessions.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            item {
                OutlinedButton(onClick = onAddManual, modifier = Modifier.fillMaxWidth()) {
                    Text("Add a session by hand")
                }
            }

            if (todaySessions.isEmpty()) {
                item { EmptyHint("Nothing logged today yet.") }
            } else {
                items(todaySessions, key = { it.id }) { session ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                            SessionHeaderRow(
                                session = session,
                                onEdit = { onEditSession(session) },
                                onDelete = { onDeleteSession(session) }
                            )
                            if (session.tasks.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                TaskGrid(session.tasks)
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

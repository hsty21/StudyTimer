package com.hasti.studytimer.data

import kotlinx.serialization.Serializable
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

@Serializable
data class Task(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    /** Optional. Null means the task was logged without a time of its own. */
    val minutes: Int? = null
)

@Serializable
data class WorkSession(
    val id: String = UUID.randomUUID().toString(),
    val startTime: Long = 0L,
    val endTime: Long = 0L,
    val tasks: List<Task> = emptyList(),
    val note: String = ""
) {
    val durationMs: Long get() = (endTime - startTime).coerceAtLeast(0L)
    val minutes: Int get() = (durationMs / 60_000L).toInt()
    val assignedMinutes: Int get() = tasks.sumOf { it.minutes ?: 0 }
    val unassignedMinutes: Int get() = (minutes - assignedMinutes).coerceAtLeast(0)
    val date: LocalDate get() = startTime.toLocalDate()
}

@Serializable
data class AppData(
    val sessions: List<WorkSession> = emptyList()
)

fun AppData.sessionsOn(date: LocalDate): List<WorkSession> =
    sessions.filter { it.date == date }.sortedBy { it.startTime }

fun AppData.tasksOn(date: LocalDate): List<Task> =
    sessionsOn(date).flatMap { it.tasks }

/** Past task names, most used first — used for the suggestion chips. */
fun AppData.taskNameHistory(): List<String> =
    sessions.flatMap { it.tasks }
        .map { it.name.trim() }
        .filter { it.isNotBlank() }
        .groupingBy { it }
        .eachCount()
        .entries
        .sortedByDescending { it.value }
        .map { it.key }

/**
 * Hasti's rule: if the task times add up to more than the clock recorded, the session
 * stretches to fit them. If they add up to less, the remainder stays unassigned.
 */
fun resolveEndTime(startTime: Long, timedMinutes: Int, tasks: List<Task>): Long {
    val assigned = tasks.sumOf { it.minutes ?: 0 }
    val finalMinutes = maxOf(timedMinutes, assigned)
    return startTime + finalMinutes * 60_000L
}

fun Long.toLocalDate(): LocalDate =
    Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()

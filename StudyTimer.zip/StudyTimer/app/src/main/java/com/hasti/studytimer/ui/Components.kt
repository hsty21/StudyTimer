package com.hasti.studytimer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.hasti.studytimer.data.Task
import com.hasti.studytimer.data.WorkSession
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

// ---- Formatting ---------------------------------------------------------------

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH)
private val dayFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)
private val shortDayFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.ENGLISH)
private val monthFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)

fun formatClock(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return String.format(
        Locale.ENGLISH, "%02d:%02d:%02d",
        total / 3600, (total % 3600) / 60, total % 60
    )
}

fun formatMinutes(minutes: Int): String {
    if (minutes <= 0) return "0m"
    if (minutes < 60) return "${minutes}m"
    val h = minutes / 60
    val m = minutes % 60
    return if (m == 0) "${h}h" else "${h}h ${m}m"
}

fun formatTimeOfDay(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault()).toLocalTime().format(timeFmt)

fun formatDay(date: LocalDate): String = date.format(dayFmt)
fun formatShortDay(date: LocalDate): String = date.format(shortDayFmt)
fun formatMonth(date: LocalDate): String = date.format(monthFmt)

// ---- Task display -------------------------------------------------------------

@Composable
fun TaskCard(task: Task, compact: Boolean, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = if (compact) 10.dp else 12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = task.name.ifBlank { "Untitled task" },
                style = if (compact) MaterialTheme.typography.bodyMedium
                else MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Medium
            )
            task.minutes?.let {
                Text(
                    text = formatMinutes(it),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

/** Two-column grid built by hand so it can live inside an outer scrolling list. */
@Composable
fun TaskGrid(tasks: List<Task>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tasks.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { task ->
                    TaskCard(task = task, compact = true, modifier = Modifier.weight(1f))
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun TaskList(tasks: List<Task>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tasks.forEach { task ->
            TaskCard(task = task, compact = false, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun SessionHeaderRow(
    session: WorkSession,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "${formatTimeOfDay(session.startTime)} \u2013 ${formatTimeOfDay(session.endTime)}",
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                buildString {
                    append(formatMinutes(session.minutes))
                    append("  \u00b7  ")
                    append("${session.tasks.size} task${if (session.tasks.size == 1) "" else "s"}")
                    if (session.unassignedMinutes > 0 && session.assignedMinutes > 0) {
                        append("  \u00b7  ")
                        append("${formatMinutes(session.unassignedMinutes)} unassigned")
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit session") }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete session") }
    }
}

// ---- Session editor -----------------------------------------------------------

private class TaskDraft(name: String = "", hours: String = "", minutes: String = "") {
    val key: String = UUID.randomUUID().toString()
    var name by mutableStateOf(name)
    var hours by mutableStateOf(hours)
    var minutes by mutableStateOf(minutes)

    fun totalMinutes(): Int? {
        val h = hours.toIntOrNull()
        val m = minutes.toIntOrNull()
        if (h == null && m == null) return null
        return (h ?: 0) * 60 + (m ?: 0)
    }

    fun toTask(): Task = Task(name = name.trim(), minutes = totalMinutes())
}

/**
 * One dialog serves three jobs: logging a finished timer session, adding a session by hand,
 * and editing an old one.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionEditorDialog(
    heading: String,
    allowDateTime: Boolean,
    initialStart: Long,
    initialMinutes: Int,
    initialTasks: List<Task>,
    history: List<String>,
    dismissLabel: String = "Discard",
    onSave: (startTime: Long, timedMinutes: Int, tasks: List<Task>) -> Unit,
    onDismiss: () -> Unit
) {
    val zone = remember { ZoneId.systemDefault() }
    val initialDateTime = remember(initialStart) {
        Instant.ofEpochMilli(initialStart).atZone(zone).toLocalDateTime()
    }

    var date by remember { mutableStateOf(initialDateTime.toLocalDate()) }
    var startHour by remember { mutableStateOf(initialDateTime.hour.toString()) }
    var startMinute by remember {
        mutableStateOf(String.format(Locale.ENGLISH, "%02d", initialDateTime.minute))
    }
    var durationHours by remember { mutableStateOf((initialMinutes / 60).toString()) }
    var durationMinutes by remember { mutableStateOf((initialMinutes % 60).toString()) }
    var note by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var focusedRow by remember { mutableStateOf(-1) }

    val drafts = remember {
        mutableStateListOf<TaskDraft>().apply {
            if (initialTasks.isEmpty()) {
                add(TaskDraft())
            } else {
                initialTasks.forEach { task ->
                    add(
                        TaskDraft(
                            name = task.name,
                            hours = task.minutes?.let { (it / 60).takeIf { h -> h > 0 }?.toString() } ?: "",
                            minutes = task.minutes?.let { (it % 60).toString() } ?: ""
                        )
                    )
                }
            }
        }
    }

    val timedMinutes = (durationHours.toIntOrNull() ?: 0) * 60 + (durationMinutes.toIntOrNull() ?: 0)
    val liveTasks = drafts.filter { it.name.isNotBlank() }.map { it.toTask() }
    val assigned = liveTasks.sumOf { it.minutes ?: 0 }
    val finalMinutes = maxOf(timedMinutes, assigned)
    val leftover = (timedMinutes - assigned).coerceAtLeast(0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(heading) },
        text = {
            Column(
                modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (allowDateTime) {
                    TextButton(onClick = { showDatePicker = true }) {
                        Text(formatDay(date))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = startHour,
                            onValueChange = { startHour = it.filter { c -> c.isDigit() }.take(2) },
                            label = { Text("Start hour") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = startMinute,
                            onValueChange = { startMinute = it.filter { c -> c.isDigit() }.take(2) },
                            label = { Text("Start min") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    Text(
                        "${formatDay(date)} \u00b7 started ${formatTimeOfDay(initialStart)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = durationHours,
                        onValueChange = { durationHours = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Hours") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Minutes") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                HorizontalDivider()
                Text("What did you get done?", style = MaterialTheme.typography.titleSmall)

                drafts.forEachIndexed { index, draft ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = draft.name,
                                onValueChange = {
                                    draft.name = it
                                    focusedRow = index
                                },
                                label = { Text("Task ${index + 1}") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { if (drafts.size > 1) drafts.removeAt(index) else draft.name = "" }
                            ) {
                                Icon(Icons.Default.Clear, contentDescription = "Remove task")
                            }
                        }

                        val suggestions = remember(draft.name, focusedRow, history) {
                            if (focusedRow != index || draft.name.isBlank()) emptyList()
                            else history.filter {
                                it.contains(draft.name.trim(), ignoreCase = true) &&
                                    !it.equals(draft.name.trim(), ignoreCase = true)
                            }.take(3)
                        }
                        if (suggestions.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                suggestions.forEach { name ->
                                    AssistChip(
                                        onClick = { draft.name = name },
                                        label = {
                                            Text(name, style = MaterialTheme.typography.labelSmall)
                                        }
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = draft.hours,
                                onValueChange = { draft.hours = it.filter { c -> c.isDigit() }.take(2) },
                                label = { Text("h (optional)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = draft.minutes,
                                onValueChange = { draft.minutes = it.filter { c -> c.isDigit() }.take(3) },
                                label = { Text("m (optional)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                TextButton(onClick = { drafts.add(TaskDraft()) }) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Add another task")
                }

                HorizontalDivider()

                Text(
                    text = when {
                        assigned > timedMinutes ->
                            "Your tasks add up to ${formatMinutes(assigned)}, so the session will be " +
                                "stretched from ${formatMinutes(timedMinutes)} to match."
                        leftover > 0 && assigned > 0 ->
                            "${formatMinutes(leftover)} will be recorded as unassigned time."
                        assigned == 0 ->
                            "No task times given, so all ${formatMinutes(timedMinutes)} stays unassigned."
                        else -> "Every minute is accounted for."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Session total: ${formatMinutes(finalMinutes)}",
                    style = MaterialTheme.typography.titleSmall
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = finalMinutes > 0,
                onClick = {
                    val startMillis = if (allowDateTime) {
                        val h = startHour.toIntOrNull()?.coerceIn(0, 23) ?: 0
                        val m = startMinute.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        LocalDateTime.of(date, java.time.LocalTime.of(h, m))
                            .atZone(zone).toInstant().toEpochMilli()
                    } else initialStart
                    onSave(startMillis, timedMinutes, liveTasks)
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(dismissLabel) } }
    )

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        date = Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
fun ConfirmDialog(
    heading: String,
    message: String,
    confirmLabel: String = "Delete",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(heading) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun EmptyHint(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

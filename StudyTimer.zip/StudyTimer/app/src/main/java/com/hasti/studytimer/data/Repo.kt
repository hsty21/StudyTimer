package com.hasti.studytimer.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

/** Everything lives in one JSON file in private storage. Nothing leaves the device. */
object Repo {

    private var file: File? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val _data = MutableStateFlow(AppData())
    val data: StateFlow<AppData> = _data.asStateFlow()

    fun init(context: Context) {
        if (file != null) return
        val f = File(context.filesDir, "study_data.json")
        file = f
        if (f.exists()) {
            runCatching { json.decodeFromString(AppData.serializer(), f.readText()) }
                .onSuccess { _data.value = it }
        }
    }

    private fun update(block: (AppData) -> AppData) {
        _data.value = block(_data.value)
        persist()
    }

    private fun persist() {
        val f = file ?: return
        val snapshot = _data.value
        scope.launch {
            runCatching { f.writeText(json.encodeToString(AppData.serializer(), snapshot)) }
        }
    }

    fun exportJson(): String = json.encodeToString(AppData.serializer(), _data.value)

    fun importJson(text: String): Boolean =
        runCatching {
            _data.value = json.decodeFromString(AppData.serializer(), text)
            persist()
            true
        }.getOrDefault(false)

    fun addSession(session: WorkSession) = update { it.copy(sessions = it.sessions + session) }

    fun updateSession(session: WorkSession) = update { d ->
        d.copy(sessions = d.sessions.map { if (it.id == session.id) session else it })
    }

    fun deleteSession(id: String) = update { d ->
        d.copy(sessions = d.sessions.filterNot { it.id == id })
    }
}

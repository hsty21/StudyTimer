package com.hasti.studytimer.data

import android.content.Context
import com.hasti.studytimer.TimerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Elapsed time is never counted in ticks. We keep the milliseconds banked from finished
 * segments plus the wall-clock instant the current segment began, so pausing, locking the
 * tablet or having the process killed can never lose or invent time.
 */
data class TimerSnapshot(
    val active: Boolean = false,
    val sessionStart: Long = 0L,
    val bankedMs: Long = 0L,
    val segmentStart: Long = 0L
) {
    val running: Boolean get() = active && segmentStart > 0L
    val paused: Boolean get() = active && segmentStart == 0L

    fun elapsedAt(now: Long): Long =
        bankedMs + if (segmentStart > 0L) (now - segmentStart).coerceAtLeast(0L) else 0L
}

object TimerState {

    private const val PREFS = "study_timer_prefs"
    private const val K_ACTIVE = "active"
    private const val K_SESSION_START = "session_start"
    private const val K_BANKED = "banked_ms"
    private const val K_SEGMENT_START = "segment_start"
    private const val K_PENDING_START = "pending_start"
    private const val K_PENDING_MS = "pending_ms"

    private val _snapshot = MutableStateFlow(TimerSnapshot())
    val snapshot: StateFlow<TimerSnapshot> = _snapshot.asStateFlow()

    /** A stopped session waiting for its tasks: session start, total elapsed millis. */
    private val _pending = MutableStateFlow<Pair<Long, Long>?>(null)
    val pending: StateFlow<Pair<Long, Long>?> = _pending.asStateFlow()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Safe to call repeatedly; re-reads what was persisted. */
    fun init(context: Context) {
        val p = prefs(context)
        _snapshot.value = TimerSnapshot(
            active = p.getBoolean(K_ACTIVE, false),
            sessionStart = p.getLong(K_SESSION_START, 0L),
            bankedMs = p.getLong(K_BANKED, 0L),
            segmentStart = p.getLong(K_SEGMENT_START, 0L)
        )
        val ps = p.getLong(K_PENDING_START, 0L)
        val pm = p.getLong(K_PENDING_MS, -1L)
        _pending.value = if (ps > 0L && pm >= 0L) ps to pm else null
    }

    private fun save(context: Context, s: TimerSnapshot) {
        prefs(context).edit()
            .putBoolean(K_ACTIVE, s.active)
            .putLong(K_SESSION_START, s.sessionStart)
            .putLong(K_BANKED, s.bankedMs)
            .putLong(K_SEGMENT_START, s.segmentStart)
            .apply()
        _snapshot.value = s
    }

    fun start(context: Context) {
        if (_snapshot.value.active) return
        val now = System.currentTimeMillis()
        save(context, TimerSnapshot(active = true, sessionStart = now, bankedMs = 0L, segmentStart = now))
        TimerService.update(context)
    }

    fun pause(context: Context, notifyService: Boolean = true) {
        val s = _snapshot.value
        if (!s.running) return
        val now = System.currentTimeMillis()
        save(
            context,
            s.copy(bankedMs = s.bankedMs + (now - s.segmentStart).coerceAtLeast(0L), segmentStart = 0L)
        )
        if (notifyService) TimerService.update(context)
    }

    fun resume(context: Context, notifyService: Boolean = true) {
        val s = _snapshot.value
        if (!s.paused) return
        save(context, s.copy(segmentStart = System.currentTimeMillis()))
        if (notifyService) TimerService.update(context)
    }

    /** Stops the clock and parks the session until tasks are entered. */
    fun finish(context: Context, notifyService: Boolean = true) {
        val s = _snapshot.value
        if (!s.active) return
        val total = s.elapsedAt(System.currentTimeMillis())
        prefs(context).edit()
            .putLong(K_PENDING_START, s.sessionStart)
            .putLong(K_PENDING_MS, total)
            .apply()
        _pending.value = s.sessionStart to total
        save(context, TimerSnapshot())
        if (notifyService) TimerService.stop(context)
    }

    fun cancel(context: Context) {
        save(context, TimerSnapshot())
        TimerService.stop(context)
    }

    fun clearPending(context: Context) {
        prefs(context).edit().remove(K_PENDING_START).remove(K_PENDING_MS).apply()
        _pending.value = null
    }
}

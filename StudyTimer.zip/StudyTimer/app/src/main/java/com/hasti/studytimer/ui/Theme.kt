package com.hasti.studytimer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Pulled from the gradient wallpaper: black, deep indigo, violet, magenta.
private val Ink = Color(0xFF0D0115)
private val DeepPurple = Color(0xFF200635)
private val Violet = Color(0xFF3F0C6B)
private val Orchid = Color(0xFF8F19A3)
private val Magenta = Color(0xFFD01C99)

private val PastelPink = Color(0xFFFFB3DE)
private val Lilac = Color(0xFFC9A7F0)
private val Mist = Color(0xFFF2E4FB)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF178CE),
    onPrimary = Color(0xFF2B0320),
    primaryContainer = Color(0xFF5B1050),
    onPrimaryContainer = PastelPink,
    secondary = Lilac,
    onSecondary = Color(0xFF240A3A),
    secondaryContainer = Color(0xFF3A1060),
    onSecondaryContainer = Color(0xFFE6D3FB),
    tertiary = PastelPink,
    tertiaryContainer = Color(0xFF4A0E4C),
    onTertiaryContainer = PastelPink,
    background = Ink,
    onBackground = Mist,
    surface = Color(0xFF241041),
    onSurface = Mist,
    surfaceVariant = Color(0xFF32154F),
    onSurfaceVariant = Color(0xFFD9C3EF),
    outline = Color(0xFF7D5A9B),
    error = Color(0xFFFF9BB0),
    onError = Color(0xFF3A0010)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF8E1E86),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFBD6EF),
    onPrimaryContainer = Color(0xFF3E0233),
    secondary = Color(0xFF6C3AA8),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEADCFB),
    onSecondaryContainer = Color(0xFF2B0B4C),
    tertiary = Color(0xFFB8407F),
    tertiaryContainer = Color(0xFFFCE0F1),
    onTertiaryContainer = Color(0xFF450527),
    background = Color(0xFFFBF2FF),
    onBackground = Color(0xFF2A0A3C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF2A0A3C),
    surfaceVariant = Color(0xFFF3E6FC),
    onSurfaceVariant = Color(0xFF52356B),
    outline = Color(0xFFBFA3D8)
)

/** The wallpaper gradient, softened so text stays readable on top of it. */
@Composable
fun backgroundBrush(): Brush =
    if (isSystemInDarkTheme())
        Brush.verticalGradient(listOf(Ink, DeepPurple, Violet, Orchid))
    else
        Brush.verticalGradient(
            listOf(Color(0xFFFBF2FF), Color(0xFFF3E1FB), Color(0xFFF7D9EF), Color(0xFFF0C9E8))
        )

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

/** A small sticker tucked into a corner, deliberately faint so it never fights the content. */
@Composable
fun CornerSticker(
    resId: Int,
    alignment: Alignment,
    size: Dp = 76.dp,
    alpha: Float = 0.5f,
    rotation: Float = 0f,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = alignment) {
        Image(
            painter = painterResource(resId),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(size)
                .rotate(rotation)
                .alpha(alpha)
        )
    }
}

@Composable
fun GradientBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(backgroundBrush())) {
        content()
    }
}

package com.hasti.studytimer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hasti.studytimer.R
import com.hasti.studytimer.data.AppData
import com.hasti.studytimer.data.WorkSession
import com.hasti.studytimer.data.sessionsOn
import com.hasti.studytimer.data.tasksOn
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(
    data: AppData,
    wide: Boolean,
    onEditSession: (WorkSession) -> Unit,
    onDeleteSession: (WorkSession) -> Unit,
    modifier: Modifier = Modifier
) {
    var monthView by remember { mutableStateOf(true) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var gridTasks by remember { mutableStateOf(true) }
    var groupBySession by remember { mutableStateOf(true) }

    Box(modifier.fillMaxSize()) {
        CornerSticker(
            resId = R.drawable.sticker_cauldron,
            alignment = Alignment.BottomEnd,
            size = 72.dp,
            alpha = 0.3f,
            rotation = 6f,
            modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
        )
        CornerSticker(
            resId = R.drawable.sticker_ghost,
            alignment = Alignment.TopEnd,
            size = 58.dp,
            alpha = 0.32f,
            rotation = -6f,
            modifier = Modifier.padding(top = 2.dp, end = 4.dp)
        )

        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = monthView,
                    onClick = { monthView = true },
                    label = { Text("Month") }
                )
                FilterChip(
                    selected = !monthView,
                    onClick = { monthView = false },
                    label = { Text("All days") }
                )
            }

            if (!monthView) {
                AllDaysList(data, gridTasks, groupBySession, onEditSession, onDeleteSession) {
                    ViewToggles(
                        gridTasks = gridTasks,
                        groupBySession = groupBySession,
                        onGridChange = { gridTasks = it },
                        onGroupChange = { groupBySession = it }
                    )
                }
            } else if (wide) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        MonthGrid(data, month, selected, { month = it }, { selected = it })
                    }
                    Column(Modifier.weight(1f)) {
                        DayPanel(
                            data, selected, gridTasks, groupBySession,
                            { gridTasks = it }, { groupBySession = it },
                            onEditSession, onDeleteSession
                        )
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    MonthGrid(data, month, selected, { month = it }, { selected = it })
                    Spacer(Modifier.height(12.dp))
                    DayPanel(
                        data, selected, gridTasks, groupBySession,
                        { gridTasks = it }, { groupBySession = it },
                        onEditSession, onDeleteSession
                    )
                }
            }
        }
    }
}

@Composable
private fun ViewToggles(
    gridTasks: Boolean,
    groupBySession: Boolean,
    onGridChange: (Boolean) -> Unit,
    onGroupChange: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = gridTasks,
                onClick = { onGridChange(true) },
                label = { Text("Grid") }
            )
            FilterChip(
                selected = !gridTasks,
                onClick = { onGridChange(false) },
                label = { Text("List") }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = groupBySession,
                onClick = { onGroupChange(true) },
                label = { Text("By session") }
            )
            FilterChip(
                selected = !groupBySession,
                onClick = { onGroupChange(false) },
                label = { Text("All tasks") }
            )
        }
    }
}

@Composable
private fun MonthGrid(
    data: AppData,
    month: YearMonth,
    selected: LocalDate,
    onMonthChange: (YearMonth) -> Unit,
    onSelect: (LocalDate) -> Unit
) {
    val today = LocalDate.now()
    val leading = month.atDay(1).dayOfWeek.value - 1 // week starts Monday
    val cells = buildList<LocalDate?> {
        repeat(leading) { add(null) }
        for (d in 1..month.lengthOfMonth()) add(month.atDay(d))
        while (size % 7 != 0) add(null)
    }

    val minutesByDate = remember(data.sessions) {
        data.sessions.groupBy { it.date }.mapValues { e -> e.value.sumOf { it.minutes } }
    }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { onMonthChange(month.minusMonths(1)) }) {
                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous month")
            }
            Text(formatMonth(month.atDay(1)), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { onMonthChange(month.plusMonths(1)) }) {
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next month")
            }
        }

        Row(Modifier.fillMaxWidth()) {
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach {
                Text(
                    it,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(4.dp))

        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { date ->
                    Box(Modifier.weight(1f).padding(2.dp)) {
                        if (date == null) {
                            Spacer(Modifier.height(52.dp).fillMaxWidth())
                        } else {
                            DayCell(
                                date = date,
                                minutes = minutesByDate[date] ?: 0,
                                isSelected = date == selected,
                                isToday = date == today,
                                onClick = { onSelect(date) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    date: LocalDate,
    minutes: Int,
    isSelected: Boolean,
    isToday: Boolean,
    onClick: () -> Unit
) {
    val worked = minutes > 0
    val background = when {
        isSelected -> MaterialTheme.colorScheme.primary
        worked -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    val contentColor = when {
        isSelected -> MaterialTheme.colorScheme.onPrimary
        worked -> MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.onSurface
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .then(
                if (isToday && !isSelected)
                    Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                else Modifier
            )
            .clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            date.dayOfMonth.toString(),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
            color = contentColor
        )
        if (worked) {
            Text(
                formatMinutes(minutes),
                style = MaterialTheme.typography.labelSmall,
                color = contentColor
            )
        }
    }
}

@Composable
private fun DayPanel(
    data: AppData,
    date: LocalDate,
    gridTasks: Boolean,
    groupBySession: Boolean,
    onGridChange: (Boolean) -> Unit,
    onGroupChange: (Boolean) -> Unit,
    onEditSession: (WorkSession) -> Unit,
    onDeleteSession: (WorkSession) -> Unit
) {
    val sessions = data.sessionsOn(date)
    val allTasks = data.tasksOn(date)
    val totalMinutes = sessions.sumOf { it.minutes }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column {
                Text(formatDay(date), style = MaterialTheme.typography.titleMedium)
                Text(
                    if (sessions.isEmpty()) "Nothing logged."
                    else "${formatMinutes(totalMinutes)}  \u00b7  ${allTasks.size} tasks  \u00b7  " +
                        "${sessions.size} session${if (sessions.size == 1) "" else "s"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (sessions.isNotEmpty()) {
            item {
                ViewToggles(gridTasks, groupBySession, onGridChange, onGroupChange)
            }

            if (groupBySession) {
                items(sessions, key = { it.id }) { session ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                            SessionHeaderRow(
                                session = session,
                                onEdit = { onEditSession(session) },
                                onDelete = { onDeleteSession(session) }
                            )
                            if (session.tasks.isEmpty()) {
                                Text(
                                    "No tasks recorded for this session.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(bottom = 10.dp)
                                )
                            } else {
                                Spacer(Modifier.height(4.dp))
                                if (gridTasks) TaskGrid(session.tasks) else TaskList(session.tasks)
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            } else {
                item {
                    if (allTasks.isEmpty()) {
                        EmptyHint("No tasks recorded on this day.")
                    } else {
                        if (gridTasks) TaskGrid(allTasks) else TaskList(allTasks)
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun AllDaysList(
    data: AppData,
    gridTasks: Boolean,
    groupBySession: Boolean,
    onEditSession: (WorkSession) -> Unit,
    onDeleteSession: (WorkSession) -> Unit,
    toggles: @Composable () -> Unit
) {
    val grouped = data.sessions
        .groupBy { it.date }
        .toSortedMap(compareByDescending<LocalDate> { it })

    if (grouped.isEmpty()) {
        EmptyHint("Nothing logged yet. Start a session on the Timer tab.")
        return
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { toggles() }

        grouped.forEach { (date, sessions) ->
            item(key = "head-$date") {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer
                    )
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatShortDay(date), style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${formatMinutes(sessions.sumOf { it.minutes })}  \u00b7  " +
                                "${sessions.sumOf { it.tasks.size }} tasks",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            if (groupBySession) {
                items(sessions.sortedBy { it.startTime }, key = { it.id }) { session ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                            SessionHeaderRow(
                                session = session,
                                onEdit = { onEditSession(session) },
                                onDelete = { onDeleteSession(session) }
                            )
                            if (session.tasks.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                if (gridTasks) TaskGrid(session.tasks) else TaskList(session.tasks)
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            } else {
                item(key = "tasks-$date") {
                    val tasks = sessions.sortedBy { it.startTime }.flatMap { it.tasks }
                    if (tasks.isEmpty()) {
                        EmptyHint("No tasks recorded on this day.")
                    } else {
                        if (gridTasks) TaskGrid(tasks) else TaskList(tasks)
                    }
                }
            }

            item(key = "div-$date") { HorizontalDivider() }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}
